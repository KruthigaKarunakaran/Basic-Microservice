package com.SpringApp.TopicBean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class TopicService {

	private static List<TopicList> topics = new ArrayList<>( Arrays.asList(
			new TopicList("Spring","Spring Framework", "Spring boot is used to build Microservices"),
			new TopicList("Microservices","Microservices","Microservices can be developed using STS"),
			new TopicList("Java","Java8","Spring and Microservices can be developed using Java8")
			));
	
	public List<TopicList> getAllTopics()
	{
		return topics;
	}
	
	public TopicList getTopic(String id)
	{
		return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
	}

	public static void addTopic(TopicList topic)
	{

		topics.add(topic);
	}

	public static void updateTopic(TopicList topic, String id) {
		
		for(int i = 0;i<topics.size();i++)
		{
			TopicList t = topics.get(i);
			if(t.getId()==id)
			{
				topics.set(i, topic);
				return;
			}
		}
	}
}
