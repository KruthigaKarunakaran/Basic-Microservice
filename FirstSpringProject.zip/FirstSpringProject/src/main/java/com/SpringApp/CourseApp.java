package com.SpringApp;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;


@SpringBootApplication
public class CourseApp {

	public static void main(String[] args) {
		SpringApplication.run(CourseApp.class,args); // give the initial method's name which is going to startup
		System.out.println("Started");

	}

}
