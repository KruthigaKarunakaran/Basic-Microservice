package com.SpringApp.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.SpringApp.TopicBean.TopicList;
import com.SpringApp.TopicBean.TopicService;

@RestController
public class SpringAppController {
	
	@Autowired
	private TopicService potopicservice;
	
	@RequestMapping("/topics")
	public List<TopicList> getAllTopics()
	{
		return potopicservice.getAllTopics();
	}

	@RequestMapping("/topics/{id}")
	public TopicList getTopic(@PathVariable String id)
	{
		return potopicservice.getTopic(id);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/topics")
	public void addTopic(@RequestBody TopicList topic)
	{
		TopicService.addTopic(topic);
	}
	

	@RequestMapping(method=RequestMethod.POST,value="/topics/{id}")
	public void updateTopic(@RequestBody TopicList topic,@PathVariable String id)
	{
		TopicService.updateTopic(topic,id);
	}
}
